package main

import (
    "os/exec"
    "strings"
    "log"
)

func getSMARTinfo(driveList []string) []map[string]string {
    var list []map[string]string

    devList := getDisksList(driveList)

    for _, dev := range devList {
        out := execute("/usr/sbin/smartctl -A " + dev)

        readFlag := false
        var names []string

        for _, line := range strings.Split(out, "\n") {
            if len(line) > 0 {
                fields := strings.Fields(line)

                if len(fields) == 10 {
                    attr := make(map[string]string)

                    if readFlag {
                        for i, v := range fields {
                            attr[names[i]] = v
                        }

                        attr["DEV"] = strings.Replace(dev, "/dev/", "", 1)
                        list = append(list, attr)
                    }

                    if fields[0] == "ID#" {
                        readFlag = true
                        names = fields
                        names[0] = "ID"
                    }
                }
            }
        }
    }

    return list
}

func getDisksList(driveList []string) []string {
    out := execute("/usr/sbin/smartctl --scan")

    var rv []string

    for _, i := range strings.Split(out, "\n") {
        if len(i) > 0 {
            dev := strings.Fields(i)[0]

            if len(driveList) > 0 && driveList[0] != "all" {
                if ! stringExistInSlice(dev, driveList) {
                    continue;
                }
            }

            rv = append(rv, dev)
        }
    }

    return rv
}

func execute(cmdString string) string {
    parts := strings.Fields(cmdString)

    head := parts[0]
    parts = parts[1:len(parts)]

    out, err := exec.Command(head, parts...).Output()

    if err != nil {
        log.Fatal(err)
    }

    return string(out)
}

func stringExistInSlice(val string, slice []string) bool {
    for _, i := range slice {
        if val == i {
            return true
        }
    }

    return false
}
