package main

import (
    _ "github.com/mattn/go-sqlite3"
    //"github.com/davecgh/go-spew/spew"

    "database/sql"
    "os"
    "log"
)

var dbFileDir string
var dbFileName string

func init() {
    dbFileDir = "/var/lib/zabbix-smart-mon"
    dbFileName = "disabled_triggers.db"

    initDB()
}

func initDB() *sql.DB {
    if _, err := os.Stat(dbFileDir); os.IsNotExist(err) {
        os.Mkdir(dbFileDir, 0755)
    }

    db, err := sql.Open("sqlite3", dbFileDir + "/" + dbFileName)
    if err != nil {
        log.Fatal(err)
    }


    createTableQuery := `
        CREATE TABLE IF NOT EXISTS disabled_triggers (
            item TEXT NOT NULL PRIMARY KEY,
            value TEXT
        )
    `

    if _, err := db.Exec(createTableQuery); err != nil {
        log.Printf("%q: %s\n", err, createTableQuery)
    }

    return db
}

func DBwrite (itemName string, value string) {
    db := initDB()

    tx, err := db.Begin()

    if err != nil {
        log.Fatal(err)
    }

    stmt, err := tx.Prepare("INSERT OR REPLACE INTO disabled_triggers(item, value) VALUES(?, ?)")
    if err != nil {
        log.Fatal(err)
    }
    defer stmt.Close()

    if _, err = stmt.Exec(itemName, value); err != nil {
        log.Fatal(err)
    }

    tx.Commit()

    defer db.Close()
}

func DBgetDisabledValue(item string) string {
    db := initDB()
    rv := "0"

    stmt, err := db.Prepare("SELECT value FROM disabled_triggers WHERE item = ?")
    if err != nil {
        log.Fatal(err)
    }
    defer stmt.Close()

    rows, err := stmt.Query(item)
    if err != nil {
        log.Fatal(err)
    }
    defer rows.Close()

    for rows.Next() {
        var value string

        if err = rows.Scan(&value); err != nil {
            log.Fatal(err)
        }

        rv = value
    }

    if err = rows.Err(); err != nil {
        log.Fatal(err)
    }

    defer db.Close()
    return rv
}

