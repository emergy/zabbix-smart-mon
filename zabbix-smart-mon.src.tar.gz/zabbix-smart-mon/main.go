package main

import (
    "github.com/jessevdk/go-flags"

    "log"
    "os"
)

type Options struct {
    Logfile     string  `short:"l"  long:"log-file"     description:"Logfile"       default:"stdout"`
    Verbose     bool    `short:"v"  long:"verbose"      description:"Verbose mode"`
}

var opts Options
var optsParser = flags.NewParser(&opts, flags.Default)

func main() {
    if _, err := optsParser.Parse(); err != nil {
        if flagsErr, ok := err.(*flags.Error); ok && flagsErr.Type == flags.ErrHelp {
            os.Exit(0)
        } else {
            os.Exit(1)
        }
    }

    if len(opts.Logfile) != 0 && opts.Logfile != "stdout" {
        f, err := os.OpenFile(opts.Logfile, os.O_RDWR | os.O_CREATE | os.O_APPEND, 0644)
        if err != nil {
            log.Fatalf("error: %v", err)
        }
        defer f.Close()

        log.SetOutput(f)
    }
}
