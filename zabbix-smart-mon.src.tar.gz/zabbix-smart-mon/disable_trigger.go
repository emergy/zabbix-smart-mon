package main

import (
    //"github.com/davecgh/go-spew/spew"

    "fmt"
)

type DisableCommand struct {
    ItemList    []string  `short:"i" description:"Item list (-i [sda:5] -i [sdb:5] ...)"  default:"all"`
}

var disableCommand DisableCommand

func (x *DisableCommand) Execute(args []string) error {
    smart := getSMARTinfo([]string{"all"})

    for _, d := range smart {
        for _, i := range x.ItemList {
            itemName := fmt.Sprintf("%s:%s", d["DEV"], d["ID"])

            if i == "all" || i == itemName {
                DBwrite(itemName, d["RAW_VALUE"])
            }
        }
    }

    return nil
}

func init() {
    optsParser.AddCommand("disable-trigger",
                          "Disable trigger",
                          "Sends the current value of the attribute to Zabbix LLD as {#DISABLED.VALUE}",
                          &disableCommand)
}

