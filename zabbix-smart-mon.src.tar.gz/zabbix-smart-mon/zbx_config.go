package main

import (
    "bufio"
    "regexp"
    "os"
    "log"
    "strings"
)

func readZabbixConfig(file string) map[string]string {
    rv := make(map[string]string)

    fileh, err := os.Open(file)
    if err != nil {
        log.Fatal(err)
    }

    defer fileh.Close()
    scanner := bufio.NewScanner(fileh)

    for scanner.Scan() {
        line := scanner.Text()

        re := regexp.MustCompile("^\\s*(#|$)")
        next := re.MatchString(line)

        if next {
            continue
        }

        sline := strings.Split(line, "=")
        rv[sline[0]] = sline[1]
    }

    if err := scanner.Err(); err != nil {
        log.Fatal(err)
    }

    return rv
}

