package main

import (
    "strings"
    "encoding/json"
    "net"
    "log"
    "fmt"
    "os/exec"
    "io"
)

type SendCommand struct {
    ZabbixAgentConfig string `short:"c" long:"zabbix-agent-config" description:"Path to zabbix_agentd.conf" default:"/etc/zabbix/zabbix_agentd.conf"`
    HostName          string `short:"H" long:"hostname"            description:"Hostname in Zabbix"         default:"from zabbix_agentd.conf"`
    ZabbixServer    []string `short:"z" long:"zabbix-server"       description:"Zabbix server host"         default:"from zabbix_agentd.conf"`
    DriveList       []string `short:"d" long:"dev"                 description:"Device"                     default:"all"`
}

var sendCommand SendCommand

type discoveryType struct {
    Device   string `json:"{#DEV}"`
    AttrId   string `json:"{#ID}"`
    AttrName string `json:"{#NAME}"`
    Worst    string `json:"{#WORST}"`
    Thresh   string `json:"{#THRESH}"`
    Disabled string `json:"{#DISABLED}"`
}

type senderOutput struct {
    Data []discoveryType `json:"data"`
}

func (x SendCommand) Execute(args []string) error {
    zaConfig := readZabbixConfig(x.ZabbixAgentConfig)

    if x.ZabbixServer[0] == "from zabbix_agentd.conf" {
        x.ZabbixServer = strings.Split(zaConfig["Server"], ",")
    }

    if x.HostName == "from zabbix_agentd.conf" {
        x.HostName = zaConfig["Hostname"]
    }

    smart := getSMARTinfo(x.DriveList)

    var discoveryHeap []discoveryType
    var senderHeap []string

    for _, i := range smart {
        discoveryHeap = append(discoveryHeap, discoveryType{
            Device: i["DEV"],
            AttrId: i["ID"],
            AttrName: i["ATTRIBUTE_NAME"],
            Worst: i["WORST"],
            Thresh: i["THRESH"],
            Disabled: DBgetDisabledValue( fmt.Sprintf("%s:%s", i["DEV"], i["ID"]) ),
        })

        senderHeap = append(senderHeap, fmt.Sprintf(`"%s" smart.mon.attr.value[%s:%s] "%s"`,
                                                    x.HostName, i["DEV"], i["ID"], i["VALUE"]))
        senderHeap = append(senderHeap, fmt.Sprintf(`"%s" smart.mon.attr.raw[%s:%s] "%s"`,
                                                    x.HostName, i["DEV"], i["ID"], i["RAW_VALUE"]))
    }

    discoveryHeap = append(discoveryHeap, discoveryType{
        Device: "dev",
        AttrId: "attrID",
        AttrName: "attrName",
        Worst: "worst",
        Thresh: "thresh",
    })

    discovery, err := json.Marshal(senderOutput{
                                       Data: discoveryHeap,
                                   })
    if err != nil {
        log.Fatal(fmt.Sprintf("Can't build discovery JSON: %s\n", err))
    }

    discoveryString := fmt.Sprintf(`"%s" smart.mon.discovery "%s"`,
                                    zaConfig["Hostname"],
                                    strings.Replace(string(discovery), "\"", "\\\"", -1))

    zabbixSend(x.ZabbixServer, []string{discoveryString})

    senderHeap = append(senderHeap, fmt.Sprintf(`"%s" smart.mon.attr.value[%s:%s] "%s"`,
                                                x.HostName, "dev", "attrID", "0"))

    partSize := 200

    for i := len(senderHeap); i >= 0; i -= partSize {
        n := i - partSize
        if (n < 0) {
            n = 0
        }

        zabbixSend(x.ZabbixServer, senderHeap[n:i])

        if (n == 0) {
            break
        }
    }

    return nil
}

func zabbixSend(server []string, data []string) {
    for _, zabbixServer := range server {
        conn, err := net.Dial("tcp", zabbixServer + ":10051")
        if err != nil {
            log.Printf("Zabbix server %s not avalible\n", zabbixServer)
            continue
        } else {
            defer conn.Close()
            log.Printf("Sendindg data to %s\n", zabbixServer)
        }

        verbose := ""
        if opts.Verbose == true {
            verbose = "-vv"
        }

        cmd := exec.Command("/usr/bin/zabbix_sender", verbose, "-z", zabbixServer, "-i", "-")
        stdin, err := cmd.StdinPipe()

        if err != nil {
            log.Fatalf("Error run zabbix_sender: %s\n", err)
        }

        go func() {
            defer stdin.Close()
            if opts.Verbose == true {
                log.Printf("Send data to zabbix server:\n%s", strings.Join(data, "\n"))
            }
            io.WriteString(stdin, strings.Join(data, "\n"))
        }()

        out, err := cmd.CombinedOutput()

        if err != nil {
            log.Printf("zabbix_sender: %s", err)
        }

        log.Printf("%s", out)
    }
}

func init() {
    optsParser.AddCommand("send",
                          "Sent monitoring data to Zabbix server",
                          "", &sendCommand)
}
